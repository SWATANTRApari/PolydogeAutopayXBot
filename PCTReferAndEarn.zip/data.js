module.exports = {
  token:'5585680001:AAHTdTVr9xtjxcEZVn9nqWD2t185o2Uov14', // token from @BotFather
  mongoLink: 'mongodb+srv://iamrudragupta:iamrudragupta2008@cluster0.qza9k.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', // mongo-link from cloud.mongodb.com
  admin: '1820548611', // admin`s id for sending him/her errors,
  currency:'PerfectWorld',
  min_wd:500000,// minimum withdrawal amount
  refer_bonus:100000,
  joinbal: 50000,
  max_wd:5000000,
  payment_channel:'@PayoutFolder',
  channel: '*👋 Hello ~ Complete Telegram Task:*\n\n🔹 Join *Unicorn Drops* [Channel](https://t.me/Unicorn_Drops) *And* [Group](t.me/unicorn_dropschat)\n🔹 Join *Airdrops Hint* [Channel](https://t.me/AirdropsHint) *and* [Group](https://t.me/AirdropsHintChat)\n🔹 Join *Champion Airdrops* [Channel](t.me/ChampionAirdrop) *And* [Group](t.me/ChampionAirdropGroup)\n🔹 Join *Payout Channel* [Payout Folder](t.me/payoutfolder] on Telegram \n*🚊 Click "Check" button if done...*',
  welcome:'*🔰 PerfectWorld Giveaway *\n*🎁 Reward Pool: 5,000,000,000 $PW*\n*👥 Referral: 500000 $PW*\n*🔥 Market: MEXC , QuickSwap*\n*📛 Winners:* For all valid users \n*🧶 Rate: ⭐️⭐️⭐️⭐️⭐️*\n*🚀 Distribution Date:* Instant to Wallet \n\n*📚 All the Tasks are Mandatory* \n     *🔹 @Unicorn_Drops*\n     *🔹 @Unicorn_DropsChat*\n     *🔹 @AirdropsHint*\n     *🔹 @ChampionAirdrop*\n     *🔹 @AirdropsHintChat  *\n     *🔹 @ChampionAirdropGroup*\n*♦️ @PayoutFolder (—payout—)*\n\n*💧 Contract:* `0xb4228798fF437ecD8fa43429664e9992256fe6Ac`\n\n*📡 Website: soon...*',
  details:'*▪️ Network:* Polygon\n*▪️ Contract Address:* `0xaaa5b9e6c589642f98a1cda99b9d024b8407285a`\n*▪️ Name:* IRON Titanium\n*▪️ Symbol:* TITAN\n*▪️ Decimals:* 18\n\n*📊 Market:* QuickSwap, MEXC',
  welcomepic: 'https://te.legra.ph/file/a8bd14b51495f5ca2102e.jpg',
  media: '*👋 Hello ~ Complete YouTube Task:*\n\n🔹 Follow *Unicorn Drops™️* on [YouTube Channel](https://youtube.com/channel/UCdYMvnmu0YnNFl_V6Db1L_w) & Like and Comment `Good` on All Videos \n\n *📝 Submit your YouTube Link..... *',
  addtext: '*💧 Submit Your Polygon (MATIC) address*\n\n‼️ *You can find it on Trust Wallet *(Do not use any exchange Address)',
  addimage: 'https://te.legra.ph/file/edfba3a641ccab7d72e70.jpg',
  symbol:'PW',
  comment: '*👋Hello ~ Complete Optional Task:*\n\n🔹 Join Our *Promoters Telegram* [Channel1](https://t.me/AirdropRampage) , [Channel2](t.me/channel) , [Channel3](t.me/channel)\n\n✅ And Click *Done☑️* Or You Can *Skip ⏭️* Also',
  bot_username:'@PerfectWorldAirdropBot',
  channels: ['@Unicorn_Drops'],
  channel1: '@Unicorn_DropsChat',
  channel2: '@AirdropsHint',
  channel3: '@PayoutFolder',
  channel4: '@AirdropsHint',
  channel5: '@ChampionAirdrop',
}

